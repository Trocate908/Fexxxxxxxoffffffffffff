"use client"

import { useState, useEffect } from "react"
import { Loader2 } from "lucide-react"
import { CommentItem } from "@/components/comment-item"
import { CommentForm } from "@/components/comment-form"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"

interface CommentsSectionProps {
  postId: string
}

type Comment = {
  id: string
  content: string
  created_at: string
  user: {
    id: string
    name: string
    username: string
    avatar_url: string | null
  }
}

export function CommentsSection({ postId }: CommentsSectionProps) {
  const [comments, setComments] = useState<Comment[]>([])
  const [loading, setLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState<Comment["user"] | null>(null)
  const { toast } = useToast()
  const supabase = createClientSupabaseClient()

  useEffect(() => {
    const fetchComments = async () => {
      try {
        setLoading(true)

        // Get current user
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (session) {
          const { data: userData } = await supabase
            .from("profiles")
            .select("id, username, full_name, avatar_url")
            .eq("id", session.user.id)
            .single()

          if (userData) {
            setCurrentUser({
              id: userData.id,
              name: userData.full_name || userData.username,
              username: userData.username,
              avatar_url: userData.avatar_url,
            })
          }
        }

        // Fetch comments
        const { data, error } = await supabase
          .from("comments")
          .select(`
            id, content, created_at,
            profiles:user_id (id, username, full_name, avatar_url)
          `)
          .eq("post_id", postId)
          .order("created_at", { ascending: true })

        if (error) throw error

        const formattedComments = data.map((comment) => ({
          id: comment.id,
          content: comment.content,
          created_at: comment.created_at,
          user: {
            id: comment.profiles.id,
            name: comment.profiles.full_name || comment.profiles.username,
            username: comment.profiles.username,
            avatar_url: comment.profiles.avatar_url,
          },
        }))

        setComments(formattedComments)
      } catch (error) {
        console.error("Error fetching comments:", error)
        toast({
          title: "Error",
          description: "Failed to load comments",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchComments()

    // Set up real-time subscription
    const commentsChannel = supabase
      .channel("comments-channel")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "comments",
          filter: `post_id=eq.${postId}`,
        },
        async (payload) => {
          // Fetch the user data for the new comment
          const { data: userData, error: userError } = await supabase
            .from("profiles")
            .select("id, username, full_name, avatar_url")
            .eq("id", payload.new.user_id)
            .single()

          if (userError) {
            console.error("Error fetching user data for new comment:", userError)
            return
          }

          const newComment: Comment = {
            id: payload.new.id,
            content: payload.new.content,
            created_at: payload.new.created_at,
            user: {
              id: userData.id,
              name: userData.full_name || userData.username,
              username: userData.username,
              avatar_url: userData.avatar_url,
            },
          }

          setComments((prev) => [...prev, newComment])
        },
      )
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: "comments",
          filter: `post_id=eq.${postId}`,
        },
        (payload) => {
          setComments((prev) => prev.filter((comment) => comment.id !== payload.old.id))
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(commentsChannel)
    }
  }, [postId, supabase, toast])

  const handleCommentDelete = (commentId: string) => {
    setComments((prev) => prev.filter((comment) => comment.id !== commentId))
  }

  return (
    <div className="space-y-4">
      <h3 className="font-medium">Comments ({comments.length})</h3>

      <CommentForm postId={postId} user={currentUser} />

      {loading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : comments.length === 0 ? (
        <div className="py-8 text-center text-muted-foreground">No comments yet. Be the first to comment!</div>
      ) : (
        <div className="space-y-1 divide-y">
          {comments.map((comment) => (
            <CommentItem
              key={comment.id}
              comment={comment}
              currentUserId={currentUser?.id || null}
              onDelete={handleCommentDelete}
            />
          ))}
        </div>
      )}
    </div>
  )
}
