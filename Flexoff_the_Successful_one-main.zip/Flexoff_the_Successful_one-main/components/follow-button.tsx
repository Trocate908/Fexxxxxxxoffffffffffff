"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

interface FollowButtonProps {
  profileId: string
  isFollowing: boolean
  isLoggedIn: boolean
}

export function FollowButton({ profileId, isFollowing: initialIsFollowing, isLoggedIn }: FollowButtonProps) {
  const [isFollowing, setIsFollowing] = useState(initialIsFollowing)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClientSupabaseClient()

  const handleFollow = async () => {
    if (!isLoggedIn) {
      router.push("/login")
      return
    }

    setIsLoading(true)

    try {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        router.push("/login")
        return
      }

      if (isFollowing) {
        // Unfollow
        const { error } = await supabase
          .from("follows")
          .delete()
          .eq("follower_id", session.user.id)
          .eq("following_id", profileId)

        if (error) throw error

        setIsFollowing(false)
        toast({
          title: "Unfollowed",
          description: "You are no longer following this user",
        })
      } else {
        // Follow
        const { error } = await supabase.from("follows").insert({
          follower_id: session.user.id,
          following_id: profileId,
        })

        if (error) throw error

        setIsFollowing(true)
        toast({
          title: "Following",
          description: "You are now following this user",
        })
      }

      router.refresh()
    } catch (error) {
      console.error("Error following/unfollowing:", error)
      toast({
        title: "Error",
        description: "Failed to update following status",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button onClick={handleFollow} disabled={isLoading} variant={isFollowing ? "outline" : "default"}>
      {isLoading ? (
        <>
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          {isFollowing ? "Unfollowing..." : "Following..."}
        </>
      ) : isFollowing ? (
        "Unfollow"
      ) : (
        "Follow"
      )}
    </Button>
  )
}
