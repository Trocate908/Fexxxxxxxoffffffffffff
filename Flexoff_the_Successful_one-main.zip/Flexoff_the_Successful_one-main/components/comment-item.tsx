"use client"

import { useState } from "react"
import { formatDistanceToNow } from "date-fns"
import { MoreHorizontal, Trash2, Heart } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"

interface CommentItemProps {
  comment: {
    id: string
    content: string
    created_at: string
    user: {
      id: string
      name: string
      username: string
      avatar_url: string | null
    }
  }
  currentUserId: string | null
  onDelete: (commentId: string) => void
}

export function CommentItem({ comment, currentUserId, onDelete }: CommentItemProps) {
  const [isDeleting, setIsDeleting] = useState(false)
  const { toast } = useToast()
  const supabase = createClientSupabaseClient()
  const isAuthor = currentUserId === comment.user.id

  const handleDelete = async () => {
    if (!currentUserId || !isAuthor) return

    setIsDeleting(true)
    try {
      const { error } = await supabase.from("comments").delete().eq("id", comment.id).eq("user_id", currentUserId)

      if (error) throw error

      onDelete(comment.id)
      toast({
        title: "Comment deleted",
        description: "Your comment has been removed",
      })
    } catch (error: any) {
      console.error("Error deleting comment:", error)
      toast({
        title: "Error",
        description: "Failed to delete comment",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  return (
    <div className="flex gap-3 py-3">
      <Avatar className="h-8 w-8">
        <AvatarImage
          src={comment.user.avatar_url || `/placeholder.svg?height=32&width=32&text=${comment.user.name.charAt(0)}`}
          alt={comment.user.name}
        />
        <AvatarFallback>{comment.user.name.charAt(0).toUpperCase()}</AvatarFallback>
      </Avatar>
      <div className="flex-1 space-y-1">
        <div className="flex items-center justify-between">
          <div>
            <span className="font-medium">{comment.user.name}</span>{" "}
            <span className="text-muted-foreground">@{comment.user.username}</span>{" "}
            <span className="text-xs text-muted-foreground">
              • {formatDistanceToNow(new Date(comment.created_at), { addSuffix: true })}
            </span>
          </div>
          {isAuthor && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreHorizontal className="h-4 w-4" />
                  <span className="sr-only">More options</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleDelete} disabled={isDeleting} className="text-red-500">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
        <p className="text-sm">{comment.content}</p>
        <div className="flex items-center gap-2 pt-1">
          <Button variant="ghost" size="sm" className="h-8 px-2">
            <Heart className="h-4 w-4 mr-1" />
            <span className="text-xs">Like</span>
          </Button>
        </div>
      </div>
    </div>
  )
}
