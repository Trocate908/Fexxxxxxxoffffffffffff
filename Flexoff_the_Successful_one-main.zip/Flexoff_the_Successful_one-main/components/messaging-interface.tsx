"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Send, Loader2 } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useToast } from "@/hooks/use-toast"

type Conversation = {
  id: string
  otherUser: {
    id: string
    username: string
    full_name: string | null
    avatar_url: string | null
  }
  lastMessage: {
    content: string
    created_at: string
  }
  unreadCount: number
}

type Message = {
  id: string
  content: string
  created_at: string
  user_id: string
  sender_is_self: boolean
}

export function MessagingInterface({ userId }: { userId: string }) {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [activeConversation, setActiveConversation] = useState<string | null>(null)
  const [activeUser, setActiveUser] = useState<Conversation["otherUser"] | null>(null)
  const [messageInput, setMessageInput] = useState("")
  const [loading, setLoading] = useState(true)
  const [sendingMessage, setSendingMessage] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const supabase = createClientSupabaseClient()
  const { toast } = useToast()

  useEffect(() => {
    fetchConversations()

    // Subscribe to new messages
    const channel = supabase
      .channel("messages")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
        },
        handleNewMessage,
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [userId])

  useEffect(() => {
    if (activeConversation) {
      fetchMessages(activeConversation)
      markMessagesAsRead(activeConversation)
    }
  }, [activeConversation])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const fetchConversations = async () => {
    setLoading(true)
    try {
      // Get all conversations the user is part of
      const { data: participations, error: participationsError } = await supabase
        .from("conversation_participants")
        .select("conversation_id")
        .eq("user_id", userId)

      if (participationsError) throw participationsError

      if (!participations.length) {
        setLoading(false)
        return
      }

      const conversationIds = participations.map((p) => p.conversation_id)

      // For each conversation, get the other participants
      const { data: otherParticipants, error: participantsError } = await supabase
        .from("conversation_participants")
        .select(`
          conversation_id,
          profiles:user_id (id, username, full_name, avatar_url)
        `)
        .in("conversation_id", conversationIds)
        .neq("user_id", userId)

      if (participantsError) throw participantsError

      // Get the last message for each conversation
      const { data: lastMessages, error: messagesError } = await supabase
        .from("messages")
        .select("*")
        .in("conversation_id", conversationIds)
        .order("created_at", { ascending: false })

      if (messagesError) throw messagesError

      // Get unread message count
      const { data: unreadCounts, error: unreadError } = await supabase
        .from("messages")
        .select("conversation_id, count")
        .in("conversation_id", conversationIds)
        .eq("read", false)
        .neq("user_id", userId)
        .group("conversation_id")

      if (unreadError) throw unreadError

      // Build conversations list
      const formattedConversations = otherParticipants
        .map((participant) => {
          const lastMessage = lastMessages.find((m) => m.conversation_id === participant.conversation_id)
          const unreadCount = unreadCounts.find((c) => c.conversation_id === participant.conversation_id)

          return {
            id: participant.conversation_id,
            otherUser: participant.profiles,
            lastMessage: lastMessage
              ? {
                  content: lastMessage.content,
                  created_at: lastMessage.created_at,
                }
              : null,
            unreadCount: unreadCount ? Number.parseInt(unreadCount.count as string) : 0,
          }
        })
        .filter((c) => c.lastMessage !== null)

      setConversations(formattedConversations)

      // Set active conversation if there isn't one
      if (!activeConversation && formattedConversations.length > 0) {
        setActiveConversation(formattedConversations[0].id)
        setActiveUser(formattedConversations[0].otherUser)
      }
    } catch (error) {
      console.error("Error fetching conversations:", error)
      toast({
        title: "Error",
        description: "Failed to load conversations",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchMessages = async (conversationId: string) => {
    try {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("conversation_id", conversationId)
        .order("created_at", { ascending: true })

      if (error) throw error

      setMessages(
        data.map((message) => ({
          ...message,
          sender_is_self: message.user_id === userId,
        })),
      )
    } catch (error) {
      console.error("Error fetching messages:", error)
      toast({
        title: "Error",
        description: "Failed to load messages",
        variant: "destructive",
      })
    }
  }

  const handleNewMessage = (payload: any) => {
    const newMessage = payload.new

    // Update messages if in the active conversation
    if (newMessage.conversation_id === activeConversation) {
      setMessages((prev) => [
        ...prev,
        {
          ...newMessage,
          sender_is_self: newMessage.user_id === userId,
        },
      ])
      markMessagesAsRead(activeConversation)
    }

    // Update conversations list
    fetchConversations()
  }

  const markMessagesAsRead = async (conversationId: string) => {
    try {
      await supabase
        .from("messages")
        .update({ read: true })
        .eq("conversation_id", conversationId)
        .neq("user_id", userId)
        .eq("read", false)
    } catch (error) {
      console.error("Error marking messages as read:", error)
    }
  }

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!messageInput.trim() || !activeConversation || sendingMessage) return

    setSendingMessage(true)

    try {
      const { error } = await supabase.from("messages").insert({
        conversation_id: activeConversation,
        user_id: userId,
        content: messageInput.trim(),
        read: false,
      })

      if (error) throw error

      setMessageInput("")
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      })
    } finally {
      setSendingMessage(false)
    }
  }

  const handleConversationSelect = (conversationId: string) => {
    setActiveConversation(conversationId)
    const selectedConversation = conversations.find((c) => c.id === conversationId)
    if (selectedConversation) {
      setActiveUser(selectedConversation.otherUser)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="grid md:grid-cols-[300px_1fr] gap-6">
      {/* Conversations List */}
      <div className="space-y-4">
        <Input placeholder="Search conversations..." />

        <div className="space-y-2">
          {conversations.length === 0 ? (
            <div className="text-center p-4 border rounded-md">
              <p className="text-muted-foreground">No conversations yet</p>
            </div>
          ) : (
            conversations.map((conversation) => (
              <div
                key={conversation.id}
                className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:bg-muted ${
                  conversation.id === activeConversation ? "bg-muted" : ""
                }`}
                onClick={() => handleConversationSelect(conversation.id)}
              >
                <Avatar>
                  <AvatarImage
                    src={
                      conversation.otherUser.avatar_url ||
                      `/placeholder.svg?height=40&width=40&text=${conversation.otherUser.username?.charAt(0)}`
                    }
                    alt={conversation.otherUser.username}
                  />
                  <AvatarFallback>{conversation.otherUser.username?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline">
                    <span className="font-medium">
                      {conversation.otherUser.full_name || conversation.otherUser.username}
                    </span>
                    {conversation.lastMessage && (
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(conversation.lastMessage.created_at), { addSuffix: true })}
                      </span>
                    )}
                  </div>
                  {conversation.lastMessage && (
                    <div className="text-sm truncate text-muted-foreground">{conversation.lastMessage.content}</div>
                  )}
                </div>
                {conversation.unreadCount > 0 && (
                  <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-xs font-medium text-primary-foreground">{conversation.unreadCount}</span>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Active Conversation */}
      {activeConversation && activeUser ? (
        <Card>
          <CardHeader className="border-b">
            <CardTitle className="flex items-center gap-3">
              <Avatar>
                <AvatarImage
                  src={
                    activeUser.avatar_url ||
                    `/placeholder.svg?height=40&width=40&text=${activeUser.username?.charAt(0)}`
                  }
                  alt={activeUser.username}
                />
                <AvatarFallback>{activeUser.username?.charAt(0).toUpperCase()}</AvatarFallback>
              </Avatar>
              <span>{activeUser.full_name || activeUser.username}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 flex flex-col h-[600px]">
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <p className="text-muted-foreground">No messages yet. Start a conversation!</p>
                </div>
              ) : (
                messages.map((message) => (
                  <div key={message.id} className={`flex ${message.sender_is_self ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[70%] rounded-lg p-3 ${
                        message.sender_is_self ? "bg-primary text-primary-foreground" : "bg-muted"
                      }`}
                    >
                      <p>{message.content}</p>
                      <p
                        className={`text-xs mt-1 ${
                          message.sender_is_self ? "text-primary-foreground/70" : "text-muted-foreground"
                        }`}
                      >
                        {formatDistanceToNow(new Date(message.created_at), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t">
              <form className="flex gap-2" onSubmit={sendMessage}>
                <Input
                  placeholder="Type a message..."
                  className="flex-1"
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  disabled={sendingMessage}
                />
                <Button size="icon" type="submit" disabled={sendingMessage || !messageInput.trim()}>
                  {sendingMessage ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  <span className="sr-only">Send message</span>
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex items-center justify-center h-[600px]">
            <p className="text-muted-foreground">Select a conversation to start chatting</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
