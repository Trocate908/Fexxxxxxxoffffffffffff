"use client"

import { useEffect, useState } from "react"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Card } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { PostFeed } from "@/components/post-feed"

export function ProfilePosts({ userId }: { userId: string }) {
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClientSupabaseClient()

  useEffect(() => {
    async function fetchPosts() {
      try {
        setLoading(true)

        const { data, error } = await supabase
          .from("posts")
          .select(`
            *,
            profiles:user_id (id, username, full_name, avatar_url),
            likes (id, user_id),
            comments (id)
          `)
          .eq("user_id", userId)
          .order("created_at", { ascending: false })

        if (error) throw error

        // Get current user to check if they liked each post
        const {
          data: { session },
        } = await supabase.auth.getSession()
        const currentUserId = session?.user?.id

        const formattedPosts = data.map((post) => ({
          id: post.id,
          content: post.content,
          image_url: post.image_url,
          created_at: post.created_at,
          user: {
            id: post.profiles.id,
            name: post.profiles.full_name || post.profiles.username,
            username: post.profiles.username,
            avatar_url: post.profiles.avatar_url,
          },
          likes_count: post.likes.length,
          comments_count: post.comments.length,
          liked_by_user: currentUserId ? post.likes.some((like: any) => like.user_id === currentUserId) : false,
        }))

        setPosts(formattedPosts)
      } catch (error) {
        console.error("Error fetching profile posts:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchPosts()
  }, [userId, supabase])

  if (loading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (posts.length === 0) {
    return (
      <Card className="p-8 text-center">
        <p className="text-muted-foreground">No posts yet</p>
      </Card>
    )
  }

  return <PostFeed initialPosts={posts} />
}
