"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/hooks/use-toast"
import { Crop, Upload, X, Loader2 } from "lucide-react"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

interface AvatarUploaderProps {
  userId: string
  username: string
  currentAvatarUrl: string | null
  onAvatarChange: (url: string | null) => void
}

export function AvatarUploader({ userId, username, currentAvatarUrl, onAvatarChange }: AvatarUploaderProps) {
  const [isUploading, setIsUploading] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [zoom, setZoom] = useState(1)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const imageRef = useRef<HTMLImageElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { toast } = useToast()
  const router = useRouter()
  const supabase = createClientSupabaseClient()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      })
      return
    }

    const reader = new FileReader()
    reader.onload = () => {
      setPreviewUrl(reader.result as string)
      setIsDialogOpen(true)
      setZoom(1)
    }
    reader.readAsDataURL(file)

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleCrop = async () => {
    if (!canvasRef.current || !imageRef.current || !previewUrl) return

    const canvas = canvasRef.current
    const image = imageRef.current
    const ctx = canvas.getContext("2d")

    if (!ctx) return

    // Set canvas dimensions to create a square crop
    canvas.width = 300
    canvas.height = 300

    // Calculate crop dimensions
    const size = Math.min(image.width, image.height) / zoom
    const offsetX = (image.width - size) / 2
    const offsetY = (image.height - size) / 2

    // Draw the cropped image on the canvas
    ctx.drawImage(image, offsetX, offsetY, size, size, 0, 0, canvas.width, canvas.height)

    // Convert canvas to blob
    canvas.toBlob(
      async (blob) => {
        if (!blob) return

        setIsUploading(true)
        setIsDialogOpen(false)

        try {
          // Check if avatars bucket exists
          const { data: buckets } = await supabase.storage.listBuckets()
          const bucketExists = buckets?.some((bucket) => bucket.name === "avatars")

          if (!bucketExists) {
            // Create the bucket with public access
            await supabase.storage.createBucket("avatars", {
              public: true,
              fileSizeLimit: 5242880, // 5MB
            })
          }

          // Upload the cropped image
          const fileName = `${userId}/${Date.now()}.jpg`
          const { error: uploadError } = await supabase.storage.from("avatars").upload(fileName, blob, { upsert: true })

          if (uploadError) throw uploadError

          // Get public URL
          const {
            data: { publicUrl },
          } = supabase.storage.from("avatars").getPublicUrl(fileName)

          // Update profile with new avatar URL
          const { error: updateError } = await supabase
            .from("profiles")
            .update({
              avatar_url: publicUrl,
              updated_at: new Date().toISOString(),
            })
            .eq("id", userId)

          if (updateError) throw updateError

          // Update local state
          onAvatarChange(publicUrl)

          toast({
            title: "Avatar updated",
            description: "Your profile picture has been updated successfully",
          })

          router.refresh()
        } catch (error: any) {
          console.error("Error uploading avatar:", error)
          toast({
            title: "Upload failed",
            description: error.message || "Failed to upload avatar",
            variant: "destructive",
          })
        } finally {
          setIsUploading(false)
          setPreviewUrl(null)
        }
      },
      "image/jpeg",
      0.9,
    )
  }

  const removeAvatar = async () => {
    if (!currentAvatarUrl) return

    setIsUploading(true)

    try {
      // Extract file path from URL
      const urlParts = currentAvatarUrl.split("/")
      const fileName = urlParts.slice(-2).join("/") // Get userId/filename.ext format

      // Delete the file from storage
      const { error: deleteError } = await supabase.storage.from("avatars").remove([fileName])

      if (deleteError) throw deleteError

      // Update profile to remove avatar URL
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          avatar_url: null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", userId)

      if (updateError) throw updateError

      // Update local state
      onAvatarChange(null)

      toast({
        title: "Avatar removed",
        description: "Your profile picture has been removed",
      })

      router.refresh()
    } catch (error: any) {
      console.error("Error removing avatar:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to remove avatar",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Avatar className="h-24 w-24 border-2 border-muted">
          <AvatarImage
            src={currentAvatarUrl || `/placeholder.svg?height=96&width=96&text=${username.charAt(0)}`}
            alt={username}
          />
          <AvatarFallback className="text-3xl">{username.charAt(0).toUpperCase()}</AvatarFallback>
        </Avatar>

        <div className="space-y-2">
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} disabled={isUploading}>
              {isUploading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
              Upload
            </Button>

            <Button variant="outline" size="sm" onClick={removeAvatar} disabled={!currentAvatarUrl || isUploading}>
              <X className="h-4 w-4 mr-2" />
              Remove
            </Button>
          </div>

          <p className="text-xs text-muted-foreground">Upload a square image for best results. Maximum size: 5MB.</p>
        </div>
      </div>

      <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Crop Profile Picture</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="relative w-full h-64 overflow-hidden rounded-md">
              {previewUrl && (
                <img
                  ref={imageRef}
                  src={previewUrl || "/placeholder.svg"}
                  alt="Preview"
                  className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 object-cover"
                  style={{
                    width: `${zoom * 100}%`,
                    height: `${zoom * 100}%`,
                  }}
                />
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm">Zoom</span>
                <span className="text-sm text-muted-foreground">{Math.round(zoom * 100)}%</span>
              </div>
              <Slider value={[zoom]} min={1} max={3} step={0.1} onValueChange={(value) => setZoom(value[0])} />
            </div>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCrop}>
                <Crop className="h-4 w-4 mr-2" />
                Apply
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Hidden canvas for cropping */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  )
}
