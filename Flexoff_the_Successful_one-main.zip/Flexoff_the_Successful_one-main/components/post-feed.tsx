"use client"

import { useEffect, useState } from "react"
import { Heart, MessageCircle, Share2, MoreHorizontal, Loader2, Clock } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { formatDistanceToNow, isPast, parseISO } from "date-fns"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

type Post = {
  id: string
  content: string
  image_url: string | null
  image_expires_at: string | null
  created_at: string
  user: {
    id: string
    name: string
    username: string
    avatar_url: string | null
  }
  likes_count: number
  comments_count: number
  liked_by_user: boolean
}

interface PostFeedProps {
  initialPosts?: Post[]
}

export function PostFeed({ initialPosts }: PostFeedProps) {
  const [posts, setPosts] = useState<Post[]>(initialPosts || [])
  const [loading, setLoading] = useState(!initialPosts)
  const [currentUser, setCurrentUser] = useState<string | null>(null)
  const { toast } = useToast()
  const router = useRouter()
  const supabase = createClientSupabaseClient()

  useEffect(() => {
    async function fetchPosts() {
      try {
        setLoading(true)

        // Get current user
        const {
          data: { session },
        } = await supabase.auth.getSession()
        setCurrentUser(session?.user?.id || null)

        // Fetch posts
        const response = await fetch("/api/posts")
        const data = await response.json()

        if (Array.isArray(data)) {
          setPosts(data)
        }
      } catch (error) {
        console.error("Error fetching posts:", error)
        toast({
          title: "Error",
          description: "Failed to load posts",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    if (!initialPosts) {
      fetchPosts()
    }

    // Subscribe to new posts
    const postsChannel = supabase
      .channel("posts-channel")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "posts",
        },
        () => {
          // Refresh posts when a new one is added
          router.refresh()
          if (!initialPosts) {
            fetchPosts()
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(postsChannel)
    }
  }, [supabase, toast, router, initialPosts])

  const handleLike = async (id: string) => {
    if (!currentUser) {
      toast({
        title: "Not logged in",
        description: "You must be logged in to like posts",
        variant: "destructive",
      })
      return
    }

    try {
      // Optimistic update
      setPosts((prevPosts) =>
        prevPosts.map((post) => {
          if (post.id === id) {
            const liked = !post.liked_by_user
            return {
              ...post,
              likes_count: liked ? post.likes_count + 1 : post.likes_count - 1,
              liked_by_user: liked,
            }
          }
          return post
        }),
      )

      // Update in database
      const { error } = await supabase
        .from("likes")
        .upsert({ post_id: id, user_id: currentUser }, { onConflict: "post_id,user_id", ignoreDuplicates: false })

      if (error) {
        if (error.code === "23505") {
          // Delete the like
          await supabase.from("likes").delete().eq("post_id", id).eq("user_id", currentUser)
        } else {
          console.error("Error liking post:", error)
          // Revert optimistic update
          setPosts((prevPosts) =>
            prevPosts.map((post) => {
              if (post.id === id) {
                const liked = !post.liked_by_user
                return {
                  ...post,
                  likes_count: liked ? post.likes_count - 1 : post.likes_count + 1,
                  liked_by_user: !liked,
                }
              }
              return post
            }),
          )
        }
      }
    } catch (error) {
      console.error("Error liking post:", error)
      toast({
        title: "Error",
        description: "Failed to like post",
        variant: "destructive",
      })
    }
  }

  // Calculate time remaining until image expiration
  const getExpirationInfo = (expiresAt: string | null) => {
    if (!expiresAt) return null

    const expirationDate = parseISO(expiresAt)

    // If already expired
    if (isPast(expirationDate)) {
      return { expired: true, timeLeft: "Expired" }
    }

    // Calculate time remaining
    const timeLeft = formatDistanceToNow(expirationDate, { addSuffix: false })
    return { expired: false, timeLeft: `${timeLeft} left` }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-48">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (posts.length === 0) {
    return (
      <div className="text-center p-12 border rounded-lg bg-background">
        <p className="text-muted-foreground">No posts yet. Be the first to share your fitness journey!</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {posts.map((post) => (
        <Card key={post.id}>
          <CardHeader className="pb-4">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage
                    src={post.user.avatar_url || `/placeholder.svg?height=40&width=40&text=${post.user.name.charAt(0)}`}
                    alt={post.user.name}
                  />
                  <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-semibold">{post.user.name}</div>
                  <div className="text-sm text-muted-foreground">
                    @{post.user.username} · {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
                  </div>
                </div>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreHorizontal className="h-4 w-4" />
                    <span className="sr-only">More options</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>Save post</DropdownMenuItem>
                  <DropdownMenuItem>Report</DropdownMenuItem>
                  <DropdownMenuItem>Hide</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </CardHeader>
          <Link href={`/post/${post.id}`}>
            <CardContent className="pb-4 hover:bg-muted/20 transition-colors">
              <p className="whitespace-pre-wrap">{post.content}</p>
              {post.image_url && (
                <div className="mt-3 rounded-md overflow-hidden relative">
                  <img
                    src={post.image_url || "/placeholder.svg"}
                    alt="Post attachment"
                    className="w-full h-auto object-cover"
                    onError={(e) => {
                      // Fallback if image fails to load
                      ;(e.target as HTMLImageElement).src =
                        "/placeholder.svg?height=300&width=500&text=Image+Unavailable"
                    }}
                  />

                  {post.image_expires_at && (
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Badge variant="secondary" className="absolute bottom-2 right-2 flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            <span>{getExpirationInfo(post.image_expires_at)?.timeLeft}</span>
                          </Badge>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>This image will be automatically deleted after 48 hours</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  )}
                </div>
              )}
            </CardContent>
          </Link>
          <CardFooter className="border-t pt-4">
            <div className="flex justify-between w-full">
              <Button
                variant="ghost"
                size="sm"
                className={`gap-1 ${post.liked_by_user ? "text-red-500" : ""}`}
                onClick={() => handleLike(post.id)}
              >
                <Heart className={`h-4 w-4 ${post.liked_by_user ? "fill-current" : ""}`} />
                <span>{post.likes_count}</span>
              </Button>
              <Link href={`/post/${post.id}`}>
                <Button variant="ghost" size="sm" className="gap-1">
                  <MessageCircle className="h-4 w-4" />
                  <span>{post.comments_count}</span>
                </Button>
              </Link>
              <Button variant="ghost" size="sm">
                <Share2 className="h-4 w-4" />
                <span className="sr-only">Share</span>
              </Button>
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
