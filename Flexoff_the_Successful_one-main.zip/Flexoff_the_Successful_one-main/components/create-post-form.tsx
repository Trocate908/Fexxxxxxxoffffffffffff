"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ImageIcon, Send, Loader2, Clock } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function CreatePostForm() {
  const [content, setContent] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const { toast } = useToast()
  const supabase = createClientSupabaseClient()

  // Get current user and ensure bucket exists
  useEffect(() => {
    const initializeForm = async () => {
      try {
        // Get current user
        const {
          data: { session },
        } = await supabase.auth.getSession()
        if (session) {
          const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()
          setUser(profile)
        }

        // Check if bucket exists and create it if it doesn't
        const { data: buckets } = await supabase.storage.listBuckets()
        const bucketExists = buckets?.some((bucket) => bucket.name === "post-images")

        if (!bucketExists) {
          // Create the bucket with public access
          await supabase.storage.createBucket("post-images", {
            public: true,
            fileSizeLimit: 5242880, // 5MB
          })
        }
      } catch (error) {
        console.error("Error initializing form:", error)
      }
    }

    initializeForm()
  }, [supabase])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!content.trim()) return

    if (!user) {
      toast({
        title: "Not logged in",
        description: "You must be logged in to create a post",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      let imageUrl = null
      let imageExpiresAt = null

      // Upload image if one was selected
      if (imageFile) {
        try {
          const fileExt = imageFile.name.split(".").pop()
          const filePath = `${user.id}/${Date.now()}.${fileExt}`

          // Check if bucket exists
          const { data: buckets } = await supabase.storage.listBuckets()
          const bucketExists = buckets?.some((bucket) => bucket.name === "post-images")

          if (!bucketExists) {
            // Create the bucket with public access
            await supabase.storage.createBucket("post-images", {
              public: true,
              fileSizeLimit: 5242880, // 5MB
            })
          }

          const { data: uploadData, error: uploadError } = await supabase.storage
            .from("post-images")
            .upload(filePath, imageFile)

          if (uploadError) {
            throw uploadError
          }

          // Get public URL
          const {
            data: { publicUrl },
          } = supabase.storage.from("post-images").getPublicUrl(filePath)

          imageUrl = publicUrl

          // Set expiration time (48 hours from now)
          const now = new Date()
          const expiresAt = new Date(now.getTime() + 48 * 60 * 60 * 1000) // 48 hours in milliseconds
          imageExpiresAt = expiresAt.toISOString()
        } catch (uploadError: any) {
          console.error("Error uploading image:", uploadError)
          toast({
            title: "Image upload failed",
            description: uploadError.message || "Could not upload image",
            variant: "destructive",
          })
          // Continue with post creation without the image
        }
      }

      // Insert post
      const { error } = await supabase.from("posts").insert({
        user_id: user.id,
        content: content,
        image_url: imageUrl,
        image_expires_at: imageExpiresAt,
      })

      if (error) throw error

      // Reset form
      setContent("")
      setImageFile(null)
      setImagePreview(null)

      toast({
        title: "Post created",
        description: imageUrl
          ? "Your post with image has been published. The image will expire after 48 hours."
          : "Your post has been published successfully.",
      })
    } catch (error: any) {
      console.error("Error creating post:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to create post",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Image must be smaller than 5MB",
        variant: "destructive",
      })
      return
    }

    setImageFile(file)

    // Create preview
    const reader = new FileReader()
    reader.onloadend = () => {
      setImagePreview(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const removeImage = () => {
    setImageFile(null)
    setImagePreview(null)
  }

  if (!user) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Create Post</CardTitle>
        </CardHeader>
        <CardContent className="text-center p-6">
          <p className="text-muted-foreground">Sign in to create posts</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create Post</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent>
          <div className="flex gap-3">
            <Avatar>
              <AvatarImage
                src={user.avatar_url || `/placeholder.svg?height=40&width=40&text=${user.username?.charAt(0)}`}
                alt={user.username}
              />
              <AvatarFallback>{user.username?.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <Textarea
                placeholder="Share your workout or fitness achievement..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="resize-none"
                rows={3}
              />

              {imagePreview && (
                <div className="relative mt-2 rounded-md overflow-hidden">
                  <img
                    src={imagePreview || "/placeholder.svg"}
                    alt="Preview"
                    className="max-h-48 w-auto object-cover"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="absolute top-2 right-2"
                    onClick={removeImage}
                  >
                    Remove
                  </Button>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Badge variant="secondary" className="absolute bottom-2 right-2 flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>Expires in 48h</span>
                        </Badge>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>This image will be automatically deleted after 48 hours</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t pt-4">
          <div>
            <input type="file" id="image-upload" accept="image/*" className="hidden" onChange={handleImageChange} />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    type="button"
                    onClick={() => document.getElementById("image-upload")?.click()}
                  >
                    <ImageIcon className="h-4 w-4 mr-2" />
                    Add Image
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Images will expire after 48 hours</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <Button size="sm" type="submit" disabled={!content.trim() || isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Posting...
              </>
            ) : (
              <>
                Post
                <Send className="h-4 w-4 ml-2" />
              </>
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
