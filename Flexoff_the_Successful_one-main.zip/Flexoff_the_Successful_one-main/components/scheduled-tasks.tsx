"use client"

import { useEffect, useRef } from "react"
import { checkAndDeleteExpiredImages } from "@/lib/actions/image-actions"

// This component doesn't render anything visible
// It just sets up background tasks
export function ScheduledTasks() {
  const checkIntervalRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    // Check for expired images every 15 minutes
    const checkExpiredImages = async () => {
      try {
        await checkAndDeleteExpiredImages()
      } catch (error) {
        console.error("Error in scheduled image check:", error)
      }
    }

    // Run once on mount
    checkExpiredImages()

    // Set up interval
    checkIntervalRef.current = setInterval(checkExpiredImages, 15 * 60 * 1000) // 15 minutes

    // Clean up on unmount
    return () => {
      if (checkIntervalRef.current) {
        clearInterval(checkIntervalRef.current)
      }
    }
  }, [])

  // This component doesn't render anything
  return null
}
