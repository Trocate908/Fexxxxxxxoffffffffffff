"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { User, Bell, Shield, Palette } from "lucide-react"

export function SettingsSidebar() {
  const pathname = usePathname()

  const links = [
    {
      href: "/settings/profile",
      label: "Profile",
      icon: User,
    },
    {
      href: "/settings/notifications",
      label: "Notifications",
      icon: Bell,
    },
    {
      href: "/settings/privacy",
      label: "Privacy & Security",
      icon: Shield,
    },
    {
      href: "/settings/appearance",
      label: "Appearance",
      icon: Palette,
    },
  ]

  return (
    <nav className="space-y-1">
      {links.map((link) => {
        const isActive = pathname === link.href
        const Icon = link.icon

        return (
          <Link
            key={link.href}
            href={link.href}
            className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
              isActive ? "bg-primary text-primary-foreground" : "hover:bg-muted"
            }`}
          >
            <Icon className="h-5 w-5" />
            <span>{link.label}</span>
          </Link>
        )
      })}
    </nav>
  )
}
