"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { SaveNotification } from "@/components/save-notification"
import { AvatarUploader } from "@/components/avatar-uploader"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Loader2 } from "lucide-react"

interface Profile {
  id: string
  username: string
  full_name: string | null
  avatar_url: string | null
  bio: string | null
}

interface ProfileEditorProps {
  initialProfile: Profile
}

export function ProfileEditor({ initialProfile }: ProfileEditorProps) {
  const [profile, setProfile] = useState<Profile>(initialProfile)
  const [originalProfile, setOriginalProfile] = useState<Profile>(initialProfile)
  const [isSaving, setIsSaving] = useState(false)
  const [showSaveNotification, setShowSaveNotification] = useState(false)
  const [errors, setErrors] = useState<{ [key: string]: string }>({})
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClientSupabaseClient()

  // Check if form has changes
  const hasChanges = () => {
    return (
      profile.username !== originalProfile.username ||
      profile.full_name !== originalProfile.full_name ||
      profile.bio !== originalProfile.bio
    )
  }

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {}

    if (!profile.username.trim()) {
      newErrors.username = "Username is required"
    } else if (profile.username.length < 3) {
      newErrors.username = "Username must be at least 3 characters"
    }

    if (profile.bio && profile.bio.length > 160) {
      newErrors.bio = "Bio must be less than 160 characters"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setIsSaving(true)

    try {
      // Check if username is already taken (except by current user)
      if (profile.username !== originalProfile.username) {
        const { data: existingUser, error: checkError } = await supabase
          .from("profiles")
          .select("id")
          .eq("username", profile.username)
          .neq("id", profile.id)
          .maybeSingle()

        if (checkError) throw checkError

        if (existingUser) {
          setErrors({ username: "Username is already taken" })
          throw new Error("Username is already taken")
        }
      }

      // Update profile
      const { error } = await supabase
        .from("profiles")
        .update({
          username: profile.username,
          full_name: profile.full_name,
          bio: profile.bio,
          updated_at: new Date().toISOString(),
        })
        .eq("id", profile.id)

      if (error) throw error

      // Update original profile state
      setOriginalProfile({ ...profile })

      // Show success notification
      setShowSaveNotification(true)

      // Refresh the page to show updated data
      router.refresh()
    } catch (error: any) {
      console.error("Error updating profile:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleAvatarChange = (url: string | null) => {
    setProfile({ ...profile, avatar_url: url })
  }

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Profile Picture</CardTitle>
        </CardHeader>
        <CardContent>
          <AvatarUploader
            userId={profile.id}
            username={profile.username}
            currentAvatarUrl={profile.avatar_url}
            onAvatarChange={handleAvatarChange}
          />
        </CardContent>
      </Card>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">
                Username <span className="text-red-500">*</span>
              </Label>
              <Input
                id="username"
                value={profile.username}
                onChange={(e) => setProfile({ ...profile, username: e.target.value })}
                error={errors.username}
                className={errors.username ? "border-red-500" : ""}
              />
              {errors.username && <p className="text-sm text-red-500">{errors.username}</p>}
              <p className="text-sm text-muted-foreground">This will be your unique identifier on the platform.</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                value={profile.full_name || ""}
                onChange={(e) => setProfile({ ...profile, full_name: e.target.value || null })}
              />
              <p className="text-sm text-muted-foreground">Your name as it will appear on your profile.</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={profile.bio || ""}
                onChange={(e) => setProfile({ ...profile, bio: e.target.value || null })}
                className={errors.bio ? "border-red-500" : ""}
                rows={4}
              />
              {errors.bio && <p className="text-sm text-red-500">{errors.bio}</p>}
              <div className="flex justify-between">
                <p className="text-sm text-muted-foreground">Tell others a little about yourself.</p>
                <p className="text-sm text-muted-foreground">{profile.bio?.length || 0}/160</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end border-t pt-4">
            <Button type="submit" disabled={!hasChanges() || isSaving}>
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </CardFooter>
        </Card>
      </form>

      <SaveNotification show={showSaveNotification} onHide={() => setShowSaveNotification(false)} />
    </div>
  )
}
