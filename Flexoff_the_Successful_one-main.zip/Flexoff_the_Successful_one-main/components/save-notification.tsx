"use client"

import { useEffect } from "react"
import { Check } from "lucide-react"

interface SaveNotificationProps {
  show: boolean
  onHide: () => void
}

export function SaveNotification({ show, onHide }: SaveNotificationProps) {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onHide()
      }, 3000)

      return () => clearTimeout(timer)
    }
  }, [show, onHide])

  if (!show) return null

  return (
    <div className="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-md shadow-lg flex items-center gap-2 animate-in slide-in-from-bottom-5">
      <Check className="h-5 w-5" />
      <span>Changes saved</span>
    </div>
  )
}
