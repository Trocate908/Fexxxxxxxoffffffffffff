"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, Send } from "lucide-react"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"

interface CommentFormProps {
  postId: string
  user: {
    id: string
    name: string
    username: string
    avatar_url: string | null
  } | null
  onCommentAdded?: () => void
}

export function CommentForm({ postId, user, onCommentAdded }: CommentFormProps) {
  const [content, setContent] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const { toast } = useToast()
  const supabase = createClientSupabaseClient()

  // Auto-resize textarea as user types
  useEffect(() => {
    const textarea = textareaRef.current
    if (!textarea) return

    const adjustHeight = () => {
      textarea.style.height = "auto"
      textarea.style.height = `${textarea.scrollHeight}px`
    }

    textarea.addEventListener("input", adjustHeight)
    return () => textarea.removeEventListener("input", adjustHeight)
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!content.trim() || !user) return

    setIsSubmitting(true)
    try {
      const { error } = await supabase.from("comments").insert({
        post_id: postId,
        user_id: user.id,
        content: content.trim(),
      })

      if (error) throw error

      setContent("")
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto"
      }

      if (onCommentAdded) {
        onCommentAdded()
      }
    } catch (error: any) {
      console.error("Error adding comment:", error)
      toast({
        title: "Error",
        description: "Failed to post comment",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center py-4 text-sm text-muted-foreground">
        Sign in to leave a comment
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-3 pt-4">
      <Avatar className="h-8 w-8">
        <AvatarImage
          src={user.avatar_url || `/placeholder.svg?height=32&width=32&text=${user.name.charAt(0)}`}
          alt={user.name}
        />
        <AvatarFallback>{user.name.charAt(0).toUpperCase()}</AvatarFallback>
      </Avatar>
      <div className="flex-1 space-y-2">
        <Textarea
          ref={textareaRef}
          placeholder="Write a comment..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="min-h-[60px] resize-none"
          disabled={isSubmitting}
        />
        <div className="flex justify-end">
          <Button type="submit" size="sm" disabled={!content.trim() || isSubmitting}>
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Posting...
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Post
              </>
            )}
          </Button>
        </div>
      </div>
    </form>
  )
}
