"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { formatDistanceToNow, isPast, parseISO } from "date-fns"
import { Heart, MessageCircle, Share2, MoreHorizontal, Clock } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface PostDetailProps {
  post: {
    id: string
    content: string
    image_url: string | null
    image_expires_at: string | null
    created_at: string
    user: {
      id: string
      name: string
      username: string
      avatar_url: string | null
    }
    likes_count: number
    comments_count: number
    liked_by_user: boolean
  }
}

export function PostDetail({ post }: PostDetailProps) {
  const [liked, setLiked] = useState(post.liked_by_user)
  const [likesCount, setLikesCount] = useState(post.likes_count)
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClientSupabaseClient()

  const handleLike = async () => {
    try {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (!session) {
        toast({
          title: "Not logged in",
          description: "You must be logged in to like posts",
          variant: "destructive",
        })
        return
      }

      // Optimistic update
      setLiked(!liked)
      setLikesCount(liked ? likesCount - 1 : likesCount + 1)

      if (liked) {
        // Unlike
        await supabase.from("likes").delete().eq("post_id", post.id).eq("user_id", session.user.id)
      } else {
        // Like
        await supabase.from("likes").insert({ post_id: post.id, user_id: session.user.id })
      }
    } catch (error) {
      console.error("Error toggling like:", error)
      // Revert optimistic update
      setLiked(!liked)
      setLikesCount(liked ? likesCount + 1 : likesCount - 1)
      toast({
        title: "Error",
        description: "Failed to update like status",
        variant: "destructive",
      })
    }
  }

  // Calculate time remaining until image expiration
  const getExpirationInfo = (expiresAt: string | null) => {
    if (!expiresAt) return null

    const expirationDate = parseISO(expiresAt)

    // If already expired
    if (isPast(expirationDate)) {
      return { expired: true, timeLeft: "Expired" }
    }

    // Calculate time remaining
    const timeLeft = formatDistanceToNow(expirationDate, { addSuffix: false })
    return { expired: false, timeLeft: `${timeLeft} left` }
  }

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage
                src={post.user.avatar_url || `/placeholder.svg?height=40&width=40&text=${post.user.name.charAt(0)}`}
                alt={post.user.name}
              />
              <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="font-semibold">{post.user.name}</div>
              <div className="text-sm text-muted-foreground">
                @{post.user.username} · {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
              </div>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">More options</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Save post</DropdownMenuItem>
              <DropdownMenuItem>Report</DropdownMenuItem>
              <DropdownMenuItem>Hide</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="pb-4">
        <p className="whitespace-pre-wrap">{post.content}</p>
        {post.image_url && (
          <div className="mt-3 rounded-md overflow-hidden relative">
            <img
              src={post.image_url || "/placeholder.svg"}
              alt="Post attachment"
              className="w-full h-auto object-cover"
              onError={(e) => {
                // Fallback if image fails to load
                ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=300&width=500&text=Image+Unavailable"
              }}
            />

            {post.image_expires_at && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Badge variant="secondary" className="absolute bottom-2 right-2 flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      <span>{getExpirationInfo(post.image_expires_at)?.timeLeft}</span>
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>This image will be automatically deleted after 48 hours</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t pt-4">
        <div className="flex justify-between w-full">
          <Button variant="ghost" size="sm" className={`gap-1 ${liked ? "text-red-500" : ""}`} onClick={handleLike}>
            <Heart className={`h-4 w-4 ${liked ? "fill-current" : ""}`} />
            <span>{likesCount}</span>
          </Button>
          <Button variant="ghost" size="sm" className="gap-1">
            <MessageCircle className="h-4 w-4" />
            <span>{post.comments_count}</span>
          </Button>
          <Button variant="ghost" size="sm">
            <Share2 className="h-4 w-4" />
            <span className="sr-only">Share</span>
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
